
-- --------------------------------------------------------

--
-- Structure de la table `contenu_chambre`
--

DROP TABLE IF EXISTS `contenu_chambre`;
CREATE TABLE IF NOT EXISTS `contenu_chambre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_chambre` int(11) NOT NULL,
  `ville` text NOT NULL,
  `quartier` text NOT NULL,
  `type_chambre` text NOT NULL,
  `image` text NOT NULL,
  `prix_par_mois` int(150) NOT NULL,
  `nombre_mois_minimum` int(100) NOT NULL,
  `nombre_chambre` int(100) NOT NULL,
  `description` text NOT NULL,
  `statut_cuisine` text NOT NULL,
  `statut_douche` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
