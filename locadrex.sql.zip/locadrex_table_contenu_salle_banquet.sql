
-- --------------------------------------------------------

--
-- Structure de la table `contenu_salle_banquet`
--

DROP TABLE IF EXISTS `contenu_salle_banquet`;
CREATE TABLE IF NOT EXISTS `contenu_salle_banquet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_salle_banquet` int(11) NOT NULL,
  `ville` text NOT NULL,
  `quartier` text NOT NULL,
  `type_evenement` text NOT NULL,
  `image` text NOT NULL,
  `prix_par_jour` int(150) NOT NULL,
  `capacite` int(150) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
