
-- --------------------------------------------------------

--
-- Structure de la table `contenu_duplex`
--

DROP TABLE IF EXISTS `contenu_duplex`;
CREATE TABLE IF NOT EXISTS `contenu_duplex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_duplex` int(11) NOT NULL,
  `ville` text NOT NULL,
  `quartier` text NOT NULL,
  `type_duplex` text NOT NULL,
  `image` text NOT NULL,
  `prix_par_mois` int(150) NOT NULL,
  `nombre_mois_minimum` int(100) NOT NULL,
  `nombre_chambre` int(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
