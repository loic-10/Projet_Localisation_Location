
-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_complet` text NOT NULL,
  `date_naissance` date NOT NULL,
  `numero_telephone` text NOT NULL,
  `adresse_email` text NOT NULL,
  `sexe` varchar(20) NOT NULL,
  `ville` text NOT NULL,
  `mot_de_passe` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
