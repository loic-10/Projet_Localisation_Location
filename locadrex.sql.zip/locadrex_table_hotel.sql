
-- --------------------------------------------------------

--
-- Structure de la table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
CREATE TABLE IF NOT EXISTS `hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_ville` int(11) NOT NULL,
  `id_quartier` int(11) NOT NULL,
  `nom` text NOT NULL,
  `images` text NOT NULL,
  `nombre_etoile` int(11) NOT NULL,
  `position_geographique` text NOT NULL,
  `validite` int(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
