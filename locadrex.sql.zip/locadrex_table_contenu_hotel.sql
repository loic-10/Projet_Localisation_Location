
-- --------------------------------------------------------

--
-- Structure de la table `contenu_hotel`
--

DROP TABLE IF EXISTS `contenu_hotel`;
CREATE TABLE IF NOT EXISTS `contenu_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_hotel` int(11) NOT NULL,
  `ville` text NOT NULL,
  `quartier` text NOT NULL,
  `type_chambre_hotel` text NOT NULL,
  `image` text NOT NULL,
  `prix_par_nuitee` int(150) NOT NULL,
  `statut_dejeune` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
