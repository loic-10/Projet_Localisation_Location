
-- --------------------------------------------------------

--
-- Structure de la table `contenu_magazin`
--

DROP TABLE IF EXISTS `contenu_magazin`;
CREATE TABLE IF NOT EXISTS `contenu_magazin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int(11) NOT NULL,
  `id_magazin` int(11) NOT NULL,
  `ville` text NOT NULL,
  `quartier` text NOT NULL,
  `image` text NOT NULL,
  `prix_par_mois` int(150) NOT NULL,
  `superficie` int(150) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
